<?php

class Index extends CI_Controller{
	function view(){	
		$this->load->helper('url');
		$data['title'] = "UMTdb HOME";
		$this->load->view('inc/header_view', $data);
		$this->load->view('index_view');
		$this->load->view('inc/footer_view');
	}	

	function login(){
		$this->load->helper('url');
		//require_once base_url()."public/php/password";

		$username = $this->input->post('username');
		$password = $this->input->post('pasword');

		$query = $this->db->get_where('users', array('username' => "kimoi"));
		$count = $this->db->count_all_results();

		echo "$count";
		if($count > 0){
			echo "1";
		}
		else{
			echo "-1";
		}
	}

	function forgotPassword(){
		
	}
}

?>