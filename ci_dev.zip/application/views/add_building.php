<html>
<head>
</head>
<body>
	<form>	
		Username: <br/>
		<input type="text" name="username" id="username" placeholder="Default: Lowercase Building Name"><br/>	
		Password:<br/>
		<input type="text" name="password" id="address" placeholder="Default: username"> <br/>
		Building Name <br/>
		<input type="text" name="buildingName" id="buildingName"> <br/>
		Address<br/>
		<input type="text" name="address" id="address"><br/>
		<input type="submit" name="addBuilding" id="addBuilding">
	</form>
</body>
</html>