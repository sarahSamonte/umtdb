<footer>
<div class="container">
<div class="row col-xs-12">
	<p class="footer-title"></p>
	<p>Copyright &copy; 2014 Utilities Monitoring Team<br/>
    UP Computer Center, Magsaysay St., University of the Philippines Diliman, Quezon City<br/>
    Tel: 931-1000</p>	
                
</div> <!-- end of row div -->
</div> <!-- end of container div -->
</footer> <!-- end of footer -->

<script src="<?=base_url()?>public/js/jquery-2.1.1.min.js"></script>
<script src="<?=base_url()?>public/js/flat-ui.min.js"></script>
<script src="<?=base_url()?>public/js/application.js"></script>

</body>
</html>