<a class="login-link" href="#forgotPasswordModal" data-toggle="modal">Forgot your password?</a>	
</div> <!-- login-form -->
</div> <!-- loginicon -->
</div>  <!-- .col-xs-4 -->
<!-- LOG-IN DIV -->
</div> <!-- row demo samples -->
