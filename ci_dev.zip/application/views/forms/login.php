<form id="form" name="login" method="POST" action="">
	<div class="form-group">
    	<input required="required" type="text" class="form-control login-field" value="" placeholder="Username" name="username" id="username" />
    	<label class="login-field-icon fui-user" for="username"></label>
    </div> <!-- form-group -->
    
    <div class="form-group">
    	<input required="required" type="password" class="form-control login-field" value="" placeholder="Password" name="password" id="password" />
    	<label class="login-field-icon fui-lock" for="password"></label>
    </div> <!-- form-group -->
    
    <input required="required" type="submit" class="btn btn-info btn-lg btn-block" value="Log in" name="login" id="login" />

</form>